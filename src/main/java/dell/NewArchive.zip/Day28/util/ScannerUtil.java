package dell.Day28.util;

import java.util.Scanner;

public class ScannerUtil {
    /**
     * 定义静态公开的scanner对象，方便其他类直接使用
     */
    public static Scanner scanner = new Scanner(System.in);
}
